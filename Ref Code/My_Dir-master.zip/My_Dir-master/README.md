# My_Dir

Download the pre-trained 100 dimensional GLoVE model from the link below:
http://nlp.stanford.edu/data/glove.6B.zip

The py file gives the code which gives word similarity based on cosine similarity index as well as gives word embedding vector for a given word.
